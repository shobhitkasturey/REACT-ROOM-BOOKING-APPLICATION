import React, { Component } from "react";

// imports react-icons
import { FaCouch, FaWifi } from "react-icons/fa";
import { BiSolidFridge } from "react-icons/bi";
import { FaKitchenSet } from "react-icons/fa6";
// imports components
import Title from "../Title/Title";

export default class Services extends Component {
  state = {
    services: [
      {
        icon: <FaCouch />,
        title: "Fully Furnished",
        info:
          "Fully furnished rooms with all the premium furnitures.",
      },
      {
        icon: <FaWifi />,
        title: "Free Wifi",
        info:
            "Free WiFi available for your comfort.",
      },
      {
        icon: <BiSolidFridge  />,
        title: "Equipped with Appliances",
        info:
          "Equipped with all the the appliances like Fridge, AC, RO purifier, Geyser.",
      },
      {
        icon: <FaKitchenSet />,
        title: "Attached washrooms and kitchen",
        info:
          "Attached washrooms and kitchen.",
      },
    ],
  };

  render() {
    return (
      <section className="services">
        <Title title="services" />

        <div className="services-center">
          {this.state.services.map((item, index) => {
            return (
              <article key={index} className="services">
                <span>{item.icon}</span>
                <h6>{item.title}</h6>
                <p>{item.info}</p>
              </article>
            );
          })}
        </div>
      </section>
    );
  }
}
